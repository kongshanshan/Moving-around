$(function () {
    $('#myTab a:first').tab('show')
});
$('#myTab>li').on('click',function(){
    $(this).addClass('tab_active').siblings().removeClass('tab_active');
});
var t=$(window).height();
$(".backSelect").bind("click",function(e){
    console.log(t);
    $("body,html").stop().animate({scrollTop:t/2.4},500);
});